<?php
// Add theme support for title tag
add_theme_support( 'title-tag' );

// Enqueue theme stylesheet
function radiance_theme_enqueue_styles() {
    wp_enqueue_style( 'radiance-style', get_stylesheet_uri() );
}
add_action( 'wp_enqueue_scripts', 'radiance_theme_enqueue_styles' );

// Force WordPress to use our custom templates regardless of page meta settings
add_filter('template_include', 'radiance_force_theme_templates', 99);
function radiance_force_theme_templates($template) {
    if (is_front_page() || is_home()) {
        $custom_front = locate_template("front-page.php");
        if ($custom_front) {
            return $custom_front;
        }
    }
    if (is_page()) {
        global $post;
        if ($post) {
            $slug = $post->post_name;
            $custom_template = locate_template("page-{$slug}.php");
            if ($custom_template) {
                return $custom_template;
            }
        }
    }
    return $template;
}
