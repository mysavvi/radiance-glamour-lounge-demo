<?php
add_theme_support( 'title-tag' );
function radiance_theme_enqueue_styles() {
    wp_enqueue_style( 'radiance-style', get_stylesheet_uri(), array(), '1.0.3' );
}
add_action( 'wp_enqueue_scripts', 'radiance_theme_enqueue_styles' );
