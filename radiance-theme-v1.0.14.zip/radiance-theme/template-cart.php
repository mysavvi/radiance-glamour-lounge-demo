<?php
/*
Template Name: Radiance - Cart
*/
get_header();
?>

<main id="neo-main" class="neo-page__main" tabindex="-1">
      <nav aria-label="Breadcrumb" class="neo-breadcrumbs-wrap">
        <ol class="neo-breadcrumbs">
          <li><a href="/">Home</a></li>
          <li><a href="/shop/">Shop</a></li>
          <li aria-current="page">Cart</li>
        </ol>
      </nav>
      <div class="neo-container rb-page-hero">
        <div style="display: flex; flex-direction: column; gap: 1.5rem; margin-bottom: 3rem;">
          <div>
            <p class="rb-eyebrow" style="color: var(--neo-accent);">Standard issue</p>
            <h1 class="neo-h1 rb-page-hero__title" style="margin-top: 0.75rem;">Your cart</h1>
            <p class="neo-body rb-muted rb-page-hero__lead" style="max-width: 600px; margin-top: 0.75rem;">At checkout you will provide shipping address, telephone, delivery method, and an optional promo code.</p>
          </div>
          <a href="/shop/" style="font-size: var(--neo-text-sm); font-weight: 600; color: var(--neo-text-primary); text-decoration: none; display: inline-flex; align-items: center; gap: 0.5rem;">
            Continue shopping
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="7" y1="17" x2="17" y2="7"/><polyline points="7 7 17 7 17 17"/></svg>
          </a>
        </div>

        <div style="display: grid; grid-template-columns: 1fr; gap: 2.5rem;">
          <style>
            @media (min-width: 1024px) {
              .neo-cart-layout { grid-template-columns: 2fr 1fr !important; }
            }
          </style>
          <div class="neo-cart-layout" style="display: grid; grid-template-columns: 1fr; gap: 2.5rem;">
            <!-- Cart Items -->
            <div id="cart-items-container" style="display: flex; flex-direction: column; gap: 1rem;">
              <!-- Handled by cart-ui.js -->
            </div>

            <!-- Order Summary Sidebar -->
            <aside>
              <div class="neo-glass-panel" style="position: sticky; top: 7rem; padding: 2rem;">
                <h2 style="font-size: 0.75rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.2em; color: var(--neo-text-muted); margin-bottom: 1.5rem; margin-top: 0;">Order summary</h2>
                <div style="border-bottom: var(--neo-border-1) solid var(--neo-border-subtle); padding-bottom: 1.5rem; margin-bottom: 1.5rem;">
                  <div style="display: flex; justify-content: space-between; font-size: var(--neo-text-base); color: var(--neo-text-secondary); margin-bottom: 0.75rem;">
                    <span>Subtotal</span>
                    <span id="cart-subtotal">&pound;45.00</span>
                  </div>
                  <p class="neo-body" style="font-size: 0.75rem; color: var(--neo-text-muted);">Delivery calculated at checkout. One discount per order: promo codes here.</p>
                </div>
                <button type="button" class="neo-btn neo-btn--primary" style="width: 100%; justify-content: center; padding: 1rem; margin-bottom: 1rem; border-radius: var(--neo-radius-full);" onclick="window.location.href='checkout.html'">Proceed to checkout</button>
                <a href="/shop/" class="neo-btn neo-btn--secondary" style="width: 100%; justify-content: center; padding: 1rem; border-radius: var(--neo-radius-full);">
                  Continue shopping
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-left: 0.5rem;"><line x1="7" y1="17" x2="17" y2="7"/><polyline points="7 7 17 7 17 17"/></svg>
                </a>
              </div>
            </aside>
          </div>
        </div>
      </div>
    </main>

<?php get_footer(); ?>
