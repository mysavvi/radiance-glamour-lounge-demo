<?php
/*
Template Name: Radiance - Contact
*/
get_header();
?>

<main id="neo-main" class="neo-page__main" tabindex="-1">
      <nav aria-label="Breadcrumb" class="neo-breadcrumbs-wrap">
        <ol class="neo-breadcrumbs">
          <li><a href="/">Home</a></li>
          <li aria-current="page">Contact</li>
        </ol>
      </nav>
      <div class="neo-container rb-page-hero">
        <p class="rb-eyebrow">Contact</p>
        <h1 class="neo-h1 rb-page-hero__title">Get in touch</h1>
        <p class="neo-body rb-muted rb-page-hero__lead">Find us in Merseyway Shopping Centre on Prince&rsquo;s Street, Stockport. Send a booking request on our website, call us, or message on Instagram.</p>

        <div class="neo-contact-grid" data-neo-reveal>
          <section class="neo-card neo-surface-raised neo-contact-card" aria-labelledby="rb-contact-name">
            <div class="neo-contact-card__header">
              <p class="neo-contact-card__tagline">Ladies-only hair and beauty salon in the heart of Stockport. Relaxed, glam and professional.</p>
            </div>
            <div class="neo-contact-card__body">
              <div class="neo-contact-card__person">
                <p class="neo-contact-card__name" id="rb-contact-name">Radiance Glamour Lounge</p>
                <p class="neo-contact-card__role">Merseyway Shopping Centre &middot; Women only</p>
              </div>
              <ul class="neo-contact-list">
                <li class="neo-contact-list__item">
                  <span class="neo-icon neo-icon-tile" aria-hidden="true">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
                  </span>
                  <span class="neo-contact-list__text">
                    <span class="neo-contact-list__label">Address</span>
                    <span class="neo-contact-list__value">12-16 Prince&rsquo;s St, Stockport SK1 1SE</span>
                    <a class="neo-contact-list__value neo-contact-list__maps-link" href="https://www.google.com/maps/search/?api=1&amp;query=12-16+Prince%27s+St,+Stockport+SK1+1SE" target="_blank" rel="noopener noreferrer">Open in Google Maps</a>
                  </span>
                </li>
                <li class="neo-contact-list__item">
                  <span class="neo-icon neo-icon-tile" aria-hidden="true">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07 19.5 19.5 0 01-6-6 19.79 19.79 0 01-3.07-8.67A2 2 0 014.11 2h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L8.09 9.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 16.92z"/></svg>
                  </span>
                  <span class="neo-contact-list__text">
                    <span class="neo-contact-list__label">Phone</span>
                    <a class="neo-contact-list__value" href="tel:07857579631">07857 579631</a>
                  </span>
                </li>
                <li class="neo-contact-list__item">
                  <span class="neo-icon neo-icon-tile" aria-hidden="true">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="2" y="2" width="20" height="20" rx="5"/><path d="M16 11.37A4 4 0 1112.63 8 4 4 0 0116 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg>
                  </span>
                  <span class="neo-contact-list__text">
                    <span class="neo-contact-list__label">Instagram</span>
                    <a class="neo-contact-list__value" href="https://www.instagram.com/radiance_glamour_lounge/" target="_blank" rel="noopener noreferrer">@radiance_glamour_lounge</a>
                  </span>
                </li>
                <li class="neo-contact-list__item">
                  <span class="neo-icon neo-icon-tile" aria-hidden="true">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
                  </span>
                  <span class="neo-contact-list__text">
                    <span class="neo-contact-list__label">Opening hours</span>
                    <span class="neo-contact-list__value rb-hours">
                      <dl>
                        <dt>Monday</dt><dd>Closed</dd>
                        <dt>Tuesday</dt><dd>10:00&ndash;17:00</dd>
                        <dt>Wednesday</dt><dd>10:00&ndash;17:00</dd>
                        <dt>Thursday</dt><dd>09:00&ndash;18:00</dd>
                        <dt>Friday</dt><dd>09:00&ndash;18:00</dd>
                        <dt>Saturday</dt><dd>09:00&ndash;18:00</dd>
                        <dt>Sunday</dt><dd>Closed</dd>
                      </dl>
                    </span>
                  </span>
                </li>
                <li class="neo-contact-list__item">
                  <span class="neo-icon neo-icon-tile" aria-hidden="true">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20"/></svg>
                  </span>
                  <span class="neo-contact-list__text">
                    <span class="neo-contact-list__label">Payment</span>
                    <span class="neo-contact-list__value">Cash and debit cards accepted</span>
                  </span>
                </li>
              </ul>
            </div>
          </section>

          <section class="neo-card neo-surface-raised rb-page-card" aria-labelledby="rb-visit-title">
            <h2 class="neo-h3" id="rb-visit-title">Visit us</h2>
            <p class="neo-body rb-muted">We&rsquo;re in Merseyway Shopping Centre on Prince&rsquo;s Street, about a 12-minute walk from Stockport train station. Bus stops are nearby.</p>
            <p class="neo-body rb-muted rb-page-card__spaced">This is a ladies-only salon. Complimentary refreshments are available during your visit.</p>
            <div class="rb-cta-row">
              <a href="/book/" class="neo-btn neo-btn--primary">Book online</a>
              <a href="tel:07857579631" class="neo-btn neo-btn--secondary">Call 07857 579631</a>
            </div>
          </section>
        </div>
      </div>
    </main>

<?php get_footer(); ?>
